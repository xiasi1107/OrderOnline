<template>
  <a-layout style="min-height: 100vh">
    <!-- 顶栏 -->
    <a-layout-header
      style="background: #7373f6; padding: 0; display: flex;
             justify-content: space-between; align-items: center;">
      <h1 style="margin-left: 3%;">MIEA</h1>
      <a-space style="display: flex; align-items: center; gap: 10px; margin-right: 3%;">
        <a-select
          ref="select"
          v-model:value="shopstate"
          style="width: 100px"
          @focus="focus"
          @change="handleChange"
        >
          <a-select-option value="营业中">营业中</a-select-option>
          <a-select-option value="打烊">打烊</a-select-option>
        </a-select>
        <a-button type="primary" shape="circle" style="float: right;">A</a-button>
      </a-space>
    </a-layout-header>

    <a-layout>
      <!-- 侧边栏 -->
      <a-layout-sider v-model:collapsed="collapsed" collapsible>
        <div class="logo" />
        <a-menu
          v-model:selectedKeys="selectedKeys"
          v-model:openKeys="openKeys"
          theme="dark"
          mode="inline"
        >
          <a-menu-item key="1">
            <router-link to="/my-shop">
              <HomeOutlined />
              <span>我的店铺</span>
            </router-link>
          </a-menu-item>

          <a-menu-item key="2">
            <router-link to="/order-management">
              <ContainerOutlined />
              <span>订单管理</span>
            </router-link>
          </a-menu-item>

          <a-menu-item key="3">
            <router-link to="/dish">
              <FileOutlined />
              <span>菜品管理</span>
            </router-link>
          </a-menu-item>

          <!-- 新增菜单项 -->
          <a-menu-item key="4">
            <router-link to="/employee">
              <TeamOutlined />
              <span>员工管理</span>
            </router-link>
          </a-menu-item>

          <a-menu-item key="5">
            <router-link to="/package">
              <GiftOutlined />
              <span>套餐管理</span>
            </router-link>
          </a-menu-item>

          <a-menu-item key="6">
            <router-link to="/statistics">
              <BarChartOutlined />
              <span>数据统计</span>
            </router-link>
          </a-menu-item>
        </a-menu>
      </a-layout-sider>

      <!-- 内容区 -->
      <a-layout>
        <a-layout-content style="margin: 16px;">
          <router-view />
        </a-layout-content>
      </a-layout>
    </a-layout>
  </a-layout>
</template>

<script setup lang="ts">
import { ref, watch } from 'vue'
import {
  FileOutlined,
  ContainerOutlined,
  HomeOutlined,
  TeamOutlined,
  GiftOutlined,
  BarChartOutlined
} from '@ant-design/icons-vue'

// 侧边栏折叠状态
const collapsed = ref(false)

// 菜单选中项
const selectedKeys = ref<string[]>(
  JSON.parse(localStorage.getItem('selectedKeys') || '["1"]')
)
watch(selectedKeys, (newVal) => {
  localStorage.setItem('selectedKeys', JSON.stringify(newVal))
}, { deep: true })

// 菜单展开项（如果有 SubMenu 用到）
// 目前没有子菜单，可保持空数组
const openKeys = ref<string[]>([])

// 商铺状态下拉框
const shopstate = ref('打烊')
const focus = () => {
  // 可在此拉取最新状态或做联动
  console.log('shopstate 下拉框获取焦点')
}
const handleChange = (value: string) => {
  shopstate.value = value
  console.log('shopstate 改为：', value)
}

// 备用方法示例
const tip = () => {
  console.log('跳转菜品管理')
}
</script>

<style scoped>
/* LOGO 区域 */
.logo {
  height: 32px;
  margin: 16px;
  background: rgba(255, 255, 255, 0.3);
}

/* 内容区背景（可选） */
.site-layout .site-layout-background {
  background: #fff;
}

/* 深色主题下背景色 */
[data-theme='dark'] .site-layout .site-layout-background {
  background: #141414;
}
</style>
