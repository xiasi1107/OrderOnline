import { createRouter, createWebHistory, RouteRecordRaw } from 'vue-router'

const routes: Array<RouteRecordRaw> = [
  // 根路径重定向到我的店铺
  { path: '/', redirect: '/my-shop' },

  {
    path: '/order-management',
    name: 'OrderManagement',
    component: () => import('@/views/OrderManagement.vue'),
    meta: {
      title: '订单管理概览'
    }
  },
  {
    path: '/my-shop',
    name: 'MyShop',
    component: () => import('@/views/MyShop.vue'),
    meta: { title: '我的店铺' }
  },
  {
    path: '/dish',
    name: 'Dish',
    component: () => import('@/views/DishView.vue'),
    meta: { title: '菜品管理' }
  },

  // 新增：员工管理
  {
    path: '/employee',
    name: 'EmployeeManagement',
    component: () => import('@/views/EmployeeManagement.vue'),
    meta: { title: '员工管理' }
  },
  // 新增：套餐管理
  {
    path: '/package',
    name: 'PackageManagement',
    component: () => import('@/views/PackageManagement.vue'),
    meta: { title: '套餐管理' }
  },
  // 新增：数据统计
  {
    path: '/statistics',
    name: 'DataStatistics',
    component: () => import('@/views/DataStatistics.vue'),
    meta: { title: '数据统计' }
  },

  // 404：所有未匹配到的路由都跳回我的店铺
  { path: '/:pathMatch(.*)*', redirect: '/my-shop' }
]

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes
})

export default router